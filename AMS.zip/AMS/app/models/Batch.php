<?php

class Batch extends Eloquent {

	protected $table = "batches";
	protected $primaryKey = 'bach_id';
}