<?php

class Attendance extends Eloquent {

	protected $table = "attendances";
	protected $primaryKey = 'atdns_id';
}