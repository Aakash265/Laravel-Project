<?php

class Subject extends Eloquent {

	protected $table = "subjects";
	protected $primaryKey = 'sbjt_id';
}