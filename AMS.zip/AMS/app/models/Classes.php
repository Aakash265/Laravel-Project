<?php

class Classes extends Eloquent {

	protected $table = "classes";
	protected $primaryKey = 'cla_id';
}